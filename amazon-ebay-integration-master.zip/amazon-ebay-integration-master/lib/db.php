<?php
require_once('meekrodb.2.3.class.php');
DB::$user="root";
DB::$password='';
DB::$dbName='ameb'
?>