<?php
require_once('config.php');
echo $twig->render('homepage.html',array('name'=>'Amarjit Singh'));
?>